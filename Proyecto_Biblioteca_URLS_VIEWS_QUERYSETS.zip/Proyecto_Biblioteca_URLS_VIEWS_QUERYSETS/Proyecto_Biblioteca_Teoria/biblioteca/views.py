from django.shortcuts import render
from .models import Biblioteca, Libro

# Create your views here.

def index(request):
    return render(request, 'index.html')
    #biblioteca= Biblioteca.objects.all()
    #return render(request, 'bibliotecaT/index.html', {'biblioteca_list':biblioteca})




def listar_libros(request):
    libros= Libro.objects.select_related("biblioteca").prefetch_related("autores")
    libros= libros.all()
    return render(request, 'libro/lista.html', {'libros_mostrar':libros})

"""
def listar_libros(request):
    libros= Libro.objects.select_related("biblioteca").prefetch_related("autores")
    libros= libros.all()
    return render(request, 'libro/lista.html', {'lista_libros':libros})
"""
